'use strict';

/**
 * account controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::account.account');
